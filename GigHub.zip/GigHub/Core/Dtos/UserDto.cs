﻿using GigHub.Core.Models;
using System.Collections.Generic;

namespace GigHub.Core.Dtos
{
    public class UserDto
    {
        public string Name { get; set; }

        public string Id { get; set; }
    }
}